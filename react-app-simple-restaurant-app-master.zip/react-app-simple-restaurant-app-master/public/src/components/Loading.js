// Loading component
export default (props) => {
	return (
		<div className="loading-div">
			<i className="fa fa-spinner fa-spin"></i>
		</div>
	)
}
