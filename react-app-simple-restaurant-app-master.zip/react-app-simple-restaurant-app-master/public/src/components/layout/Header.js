// components
import Title from "./Title"

export default ({ userInfo }) => {
  return (
    <div className="header">
      <Title />
    </div>
  )
}
