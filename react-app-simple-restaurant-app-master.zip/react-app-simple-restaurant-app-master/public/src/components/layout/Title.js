// Title component
export default () => {
  return (
    <div className="title">
      Simple <span className="bold-title">Restaurant Application</span>
    </div>
  )
}
