// import the render function
import { render } from "react-dom"

// the actual App component
import App from "./App"

render(<App />, document.getElementById("app"))
