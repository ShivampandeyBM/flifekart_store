from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from flask_mysqldb import MySQL

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'SayCheese'

mysql = MySQL(app)

@app.route('/')
def home():
    return redirect(url_for('login'))

# ------------------- LOGIN -------------------
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
        user = cur.fetchone()
        cur.close()

        if user:
            session['username'] = user[1]  # assuming column 1 is username
            session['role'] = user[3]      # assuming column 3 is role: 'admin' or 'user'

            if session['role'] == 'admin':
                return redirect(url_for('index_admin'))
            else:
                return redirect(url_for('index_user'))
        else:
            return render_template('login.html', error='Invalid username or password')

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

# ------------------- INDEX -------------------
@app.route('/index_admin')
def index_admin():
    if session.get('role') != 'admin':
        return redirect(url_for('login'))
    return render_template('index_admin.html')

@app.route('/index_user')
def index_user():
    if session.get('role') != 'user':
        return redirect(url_for('login'))
    return render_template('index_user.html')

# ------------------- MENU -------------------
@app.route('/menu')
def menu():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('menu.html')

# ------------------- RESERVE -------------------
@app.route('/reserve', methods=['GET', 'POST'])
def reserve():
    if 'username' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        date = request.form['date']
        message = request.form['message']

        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO reservations (name, email, date, message) VALUES (%s, %s, %s, %s)",
                    (name, email, date, message))
        mysql.connection.commit()
        cur.close()

        return render_template('reserve.html', success='Reservation submitted!')

    return render_template('reserve.html')

# ------------------- CART -------------------
@app.route('/cart')
def cart():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('cart.html')

# ------------------- ORDER -------------------
@app.route('/order', methods=['POST'])
def place_order():
    if 'username' not in session:
        return jsonify({"status": "error", "message": "Login required"}), 403

    try:
        data = request.get_json()
        if not data.get('items'):
            return jsonify({"status": "error", "message": "Cart is empty"}), 400

        customer_name = data.get('customer_name', 'Guest')
        cur = mysql.connection.cursor()

        for item in data['items']:
            name = item['name']
            qty = item['quantity']
            price = item['price']
            cur.execute("INSERT INTO orders (customer_name, item_name, quantity, price) VALUES (%s, %s, %s, %s)",
                        (customer_name, name, qty, price))

        mysql.connection.commit()
        cur.close()

        return jsonify({"status": "success", "message": "Order placed successfully!"})

    except Exception as e:
        print("Error:", e)
        return jsonify({"status": "error", "message": "An error occurred while placing the order."}), 500

if __name__ == '__main__':
    app.run(debug=True)
