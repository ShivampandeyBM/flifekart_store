
document.addEventListener("DOMContentLoaded", () => {
    const form = document.querySelector("form");
    if (form) {
        form.addEventListener("submit", function (e) {
            const name = form.name.value.trim();
            const email = form.email.value.trim();

            if (!name || !email) {
                e.preventDefault();
                alert("Please fill out your name and email.");
            } else {
                setTimeout(() => {
                    alert("🎉 Thank you! Your reservation has been submitted.");
                }, 100);
            }
        });
    }

    // Dark mode toggle
    const toggle = document.createElement("button");
    toggle.innerText = "🌙 Toggle Dark Mode";
    toggle.style.margin = "10px";
    document.body.insertBefore(toggle, document.body.firstChild);

    toggle.addEventListener("click", () => {
        document.body.classList.toggle("dark-mode");
    });
});
